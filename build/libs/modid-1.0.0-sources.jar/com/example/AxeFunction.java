package com.example;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AxeFunction {



    public static final String MOD_ID = "mrmods";


    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    int speed1 = 7;
    int speed1ё = 6;
    int speed3 = 5;
    int speed4 = 4;

    public AxeFunction() {
        LOGGER.info("AxeFunctionINIT");
    }

    public int speedAxe(class_1799 id) {
        class_1792 item = id.method_7909();
        if (item.equals(class_1802.field_8062)) {
            return speed1;
        }

        if (item.equals(class_1802.field_8062)) {
            return speed1ё;
        }

        if (item.equals(class_1802.field_8475)) {
            return speed3;
        }

        if (item.equals(class_1802.field_8825)) {
            return speed3;
        }

        if (item.equals(class_1802.field_8556)) {
            return speed4;
        }

        if (item.equals(class_1802.field_22025)) {
            return speed4;
        }

        return 10;
    }
}
