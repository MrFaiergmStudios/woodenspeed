package com.example;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AxeFunction {



    public static final String MOD_ID = "mrmods";


    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    int speed1 = 7;
    int speed1ё = 6;
    int speed2 = 5;
    int speed3 = 5;
    int speed4 = 4;

    public AxeFunction() {
        LOGGER.info("AxeFunctionINIT");
    }

    public int speedAxe(class_1799 id) {
        if (id.method_31574(class_1802.field_8406)) {
            return speed1;
        }

        if (id.method_31574(class_1802.field_8062)) {
            return speed1ё;
        }

        if (id.method_31574(class_1802.field_61341)) {
            return speed2;
        }

        if (id.method_31574(class_1802.field_8475)) {
            return speed3;
        }

        if (id.method_31574(class_1802.field_8825)) {
            return speed3;
        }

        if (id.method_31574(class_1802.field_8556)) {
            return speed4;
        }

        if (id.method_31574(class_1802.field_22025)) {
            return speed4;
        }

        return 10;
    }
}
