package com.example;

import com.ibm.icu.text.Transliterator;
import net.fabricmc.api.ModInitializer;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayDeque;
import java.util.Queue;

public class ExampleMod implements ModInitializer {
	public static final String MOD_ID = "mrmods";


	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private final Queue<class_2338> blockPosSpisok = new ArrayDeque<>();

	public Timers timer = new Timers();

	public AxeFunction AxeFnction = new AxeFunction();

	int while1 = 1;

	int timeinBreakWood = 0;

	class_1937 worldGl = null;


	@Override
	public void onInitialize() {

		PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
			class_1799 PlayerHalde = player.method_6047();

			worldGl = world;
			if (!world.method_8608() && state.method_26164(class_3481.field_15475) && PlayerHalde.method_31573(class_3489.field_42612)) {
				class_2338 positionBlock = pos;
				class_2338 positionBlockInUp = positionBlock;

				int blocks = 0;

				timeinBreakWood = AxeFnction.speedAxe(PlayerHalde);

				LOGGER.info("timewood:\n {}", + timeinBreakWood);

				while1 = 1;

				if (while1 == 1) {
					LOGGER.info("Вызван цикл");
				}
				while (while1 == 1) {
					positionBlockInUp = positionBlockInUp.method_10084();
					if (world.method_8320(positionBlockInUp).method_26164(class_3481.field_15475)) {
						blockPosSpisok.add(positionBlockInUp);
					} else if (!world.method_8320(positionBlockInUp).method_26164(class_3481.field_15475)) {
						while1 = 0;
						LOGGER.info("цикл был завершен бревнов насчитанно:" + blockPosSpisok.size());
						positionBlockInUp = positionBlock;
						blocks = blockPosSpisok.size();
						LOGGER.info("Таймер был запущен");
						timer.TimerStart(timeinBreakWood);
						break;
					}
				}
			}
			return true;


		});

		ServerTickEvents.END_SERVER_TICK.register(server -> {

			if (while1 == 0 && !blockPosSpisok.isEmpty()) {
				int timerEnd = timer.TimerEnd;
				if(timerEnd == 1){
					class_2338 blockisBreaks = blockPosSpisok.poll();
					LOGGER.info("Блок Был сломан");
					worldGl.method_22352(blockisBreaks, true);
					if(!blockPosSpisok.isEmpty()){
						timer.TimerStart(timeinBreakWood);
						LOGGER.info("новый таймер был заведен");
					}
				}
			}
		});

	}

	public static class_2960 id(String path) {
		return class_2960.method_43902(MOD_ID, path);
	}
}
