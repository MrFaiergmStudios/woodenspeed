/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.dimension;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import io.netty.buffer.Unpooled;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import net.fabricmc.fabric.api.dimension.v1.FabricDimensionType;
import net.fabricmc.fabric.api.network.ServerSidePacketRegistry;
import net.fabricmc.fabric.impl.registry.sync.RemapException;
import net.minecraft.core.Registry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.Packet;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.storage.LevelData;

/**
 * Handles fixing raw dimension ids between saves and servers,
 * and synchronizes said ids.
 */
public class DimensionIdsFixer {
	private static final Field FABRIC_DIMENSION_TYPE$RAW_ID;
	static final ResourceLocation ID = new ResourceLocation("fabric", "dimension/sync");

	/**
	 * Assigns a unique id to every registered {@link FabricDimensionType}, keeping the known ids
	 * from {@code savedIds}.
	 *
	 * @param savedIds a compound tag mapping dimension ids to raw ids
	 * @return id to raw id mappings of the current instance
	 * @throws RemapException if dimensions IDs conflict irredeemably
	 */
	public static CompoundTag apply(CompoundTag savedIds) throws RemapException {
		/*
		 * We want to give to each fabric dimension a unique ID. We also want to give back previously assigned ids.
		 * And we have to take into account non-fabric dimensions, which raw IDs cannot change.
		 * So we iterate over every dimension, note the ones which id cannot change, then update the free ones.
		 */
		Int2ObjectMap<ResourceLocation> fixedIds = new Int2ObjectOpenHashMap<>();
		List<FabricDimensionType> fabricDimensions = new ArrayList<>();
		CompoundTag fabricDimensionIds = new CompoundTag();

		// step 1: detect all fabric and non-fabric dimensions
		for (ResourceLocation id : Registry.DIMENSION_TYPE.keySet()) {
			DimensionType dimensionType = Objects.requireNonNull(DimensionType.getByName(id));

			if (dimensionType instanceof FabricDimensionType) {
				FabricDimensionType fabricDimension = (FabricDimensionType) dimensionType;
				fabricDimensions.add(fabricDimension);
				// reset the fixed raw id to the preferred raw id
				setFixedRawId(fabricDimension, fabricDimension.getDesiredRawId());
			} else {
				ResourceLocation existing = fixedIds.put(dimensionType.getId(), id);

				if (existing != null) {
					throw new RemapException("Two non-fabric dimensions have the same raw dim id (" + dimensionType.getId() + ") : " + existing + " and " + id);
				}
			}
		}

		// step 2: read saved ids
		for (String key : savedIds.getAllKeys()) {
			int savedRawId = savedIds.getInt(key);
			ResourceLocation dimId = new ResourceLocation(key);
			ResourceLocation existing = fixedIds.putIfAbsent(savedRawId, dimId);

			if (existing != null && !existing.equals(dimId)) {
				throw new RemapException("Saved fabric dimension got replaced with a non-fabric one! " + dimId + " replaced with " + existing + " (raw id: " + savedRawId + ")");
			}

			DimensionType dim = DimensionType.getByName(dimId);

			if (dim instanceof FabricDimensionType) {
				setFixedRawId((FabricDimensionType) dim, savedRawId);
			} else {
				FabricDimensionInternals.LOGGER.warn("A saved dimension has {}: {}", dim == null ? "been removed" : "stopped using the dimensions API", dimId);
				// Preserve saved ids in case the mod is eventually added back
				fabricDimensionIds.putInt(dimId.toString(), savedRawId);
			}
		}

		// step 3: de-duplicate raw ids for dimensions which ids are not fixed yet
		int nextFreeId = 0;

		for (FabricDimensionType fabricDimension : fabricDimensions) {
			int rawDimId = fabricDimension.getId();
			ResourceLocation dimId = Objects.requireNonNull(DimensionType.getName(fabricDimension));

			if (fixedIds.containsKey(rawDimId) && !fixedIds.get(rawDimId).equals(dimId)) {
				while (fixedIds.containsKey(nextFreeId)) ++nextFreeId;
				setFixedRawId(fabricDimension, nextFreeId);
				rawDimId = nextFreeId;
			}

			fixedIds.put(rawDimId, dimId);
			fabricDimensionIds.putInt(dimId.toString(), rawDimId);
		}

		return fabricDimensionIds;
	}

	/**
	 * Reflectively set the fixed raw id on a {@link FabricDimensionType}.
	 *
	 * @see FabricDimensionType#getRawId()
	 */
	private static void setFixedRawId(FabricDimensionType fabricDimension, int rawId) {
		try {
			FABRIC_DIMENSION_TYPE$RAW_ID.setInt(fabricDimension, rawId);
		} catch (IllegalAccessException e) {
			throw new RuntimeException("Failed to fix a raw id on a FabricDimensionType", e);
		}
	}

	public static Packet<?> createPacket(LevelData levelProperties) {
		FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
		buf.writeNbt(((DimensionIdsHolder) levelProperties).fabric_getDimensionIds());
		return ServerSidePacketRegistry.INSTANCE.toPacket(ID, buf);
	}

	static {
		try {
			FABRIC_DIMENSION_TYPE$RAW_ID = FabricDimensionType.class.getDeclaredField("fixedRawId");
			FABRIC_DIMENSION_TYPE$RAW_ID.setAccessible(true);
		} catch (NoSuchFieldException e) {
			throw new RuntimeException(e);
		}
	}
}
