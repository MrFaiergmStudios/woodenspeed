/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.object.builder;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.MaterialColor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Block.Properties.class)
public interface BlockSettingsAccessor {
	/* GETTERS */
	@Accessor
	Material getMaterial();

	@Accessor
	float getHardness();

	@Accessor
	float getResistance();

	@Accessor
	boolean getCollidable();

	@Accessor
	boolean getRandomTicks();

	@Accessor
	int getLuminance();

	@Accessor
	MaterialColor getMaterialColor();

	@Accessor
	SoundType getSoundGroup();

	@Accessor
	float getSlipperiness();

	@Accessor
	boolean getDynamicBounds();

	/* SETTERS */
	@Accessor
	void setMaterial(Material material);

	@Accessor
	void setHardness(float hardness);

	@Accessor
	void setResistance(float resistance);

	@Accessor
	void setCollidable(boolean collidable);

	@Accessor
	void setRandomTicks(boolean ticksRandomly);

	@Accessor
	void setMaterialColor(MaterialColor materialColor);

	@Accessor
	void setDropTableId(ResourceLocation dropTableId);

	@Accessor
	void setDynamicBounds(boolean dynamicBounds);

	/* INVOKERS */

	@Invoker
	Block.Properties invokeSounds(SoundType group);

	@Invoker
	Block.Properties invokeLightLevel(int lightLevel);

	@Invoker
	Block.Properties invokeBreakInstantly();

	@Invoker
	Block.Properties invokeStrength(float strength);

	@Invoker
	Block.Properties invokeTicksRandomly();

	@Invoker
	Block.Properties invokeHasDynamicBounds();

	@Invoker
	Block.Properties invokeDropsNothing();
}
