/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.registry.sync.trackers.vanilla;

import java.util.Objects;

import it.unimi.dsi.fastutil.ints.Int2IntMap;
import net.fabricmc.fabric.api.event.registry.RegistryEntryAddedCallback;
import net.fabricmc.fabric.api.event.registry.RegistryEntryRemovedCallback;
import net.fabricmc.fabric.api.event.registry.RegistryIdRemapCallback;
import net.fabricmc.fabric.impl.registry.sync.RemovableIdList;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;

public final class BiomeParentTracker implements RegistryEntryAddedCallback<Biome>, RegistryEntryRemovedCallback<Biome>, RegistryIdRemapCallback<Biome> {
	private final Registry<Biome> registry;

	private BiomeParentTracker(Registry<Biome> registry) {
		this.registry = registry;
	}

	public static void register(Registry<Biome> registry) {
		BiomeParentTracker tracker = new BiomeParentTracker(registry);
		RegistryEntryAddedCallback.event(registry).register(tracker);
		RegistryIdRemapCallback.event(registry).register(tracker);
		RegistryEntryRemovedCallback.event(registry).register(tracker);
	}

	@Override
	public void onEntryAdded(int rawId, ResourceLocation id, Biome object) {
		if (object.isMutated()) {
			Biome.MUTATED_BIOMES.addMapping(object, registry.getId(registry.get(new ResourceLocation(Objects.requireNonNull(object.getParent())))));
		}
	}

	@Override
	public void onRemap(RemapState<Biome> state) {
		for (Int2IntMap.Entry entry : state.getRawIdChangeMap().int2IntEntrySet()) {
			if (Biome.MUTATED_BIOMES.byId(entry.getIntKey()) != null) {
				//noinspection unchecked
				((RemovableIdList<Biome>) Biome.MUTATED_BIOMES).fabric_remapId(entry.getIntKey(), entry.getIntValue());
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public void onEntryRemoved(int rawId, ResourceLocation id, Biome object) {
		((RemovableIdList<Biome>) Biome.MUTATED_BIOMES).fabric_remove(object);
		((RemovableIdList<Biome>) Biome.MUTATED_BIOMES).fabric_removeId(rawId);
	}
}
