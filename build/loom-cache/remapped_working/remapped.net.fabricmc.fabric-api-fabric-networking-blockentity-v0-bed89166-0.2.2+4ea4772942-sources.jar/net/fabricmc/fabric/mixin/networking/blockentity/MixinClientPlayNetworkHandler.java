/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.networking.blockentity;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import net.fabricmc.fabric.api.block.entity.BlockEntityClientSerializable;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

@Mixin(ClientPacketListener.class)
public class MixinClientPlayNetworkHandler {
	@Unique
	private static Logger FABRIC_LOGGER = LogManager.getLogger();

	@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/packet/BlockEntityUpdateS2CPacket;getActionId()I", ordinal = 0), method = "onBlockEntityUpdate", cancellable = true, locals = LocalCapture.CAPTURE_FAILHARD)
	public void onBlockEntityUpdate(ClientboundBlockEntityDataPacket packet, CallbackInfo info, BlockEntity entity) {
		if (entity instanceof BlockEntityClientSerializable) {
			if (packet.getType() == 127) {
				BlockEntityClientSerializable serializable = (BlockEntityClientSerializable) entity;
				String id = packet.getTag().getString("id");

				if (id != null) {
					ResourceLocation otherIdObj = BlockEntityType.getKey(entity.getType());

					if (otherIdObj == null) {
						FABRIC_LOGGER.error(entity.getClass() + " is missing a mapping! This is a bug!");
						info.cancel();
						return;
					}

					String otherId = otherIdObj.toString();

					if (otherId.equals(id)) {
						serializable.fromClientTag(packet.getTag());
					}
				}
			}

			info.cancel();
		}
	}

	@Redirect(method = "onChunkData", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/entity/BlockEntity;fromTag(Lnet/minecraft/nbt/CompoundTag;)V"))
	public void deserializeBlockEntityChunkData(BlockEntity entity, CompoundTag tag) {
		if (entity instanceof BlockEntityClientSerializable) {
			((BlockEntityClientSerializable) entity).fromClientTag(tag);
		} else {
			entity.load(tag);
		}
	}
}
