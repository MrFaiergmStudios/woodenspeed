/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.tag;

import java.util.function.Supplier;
import net.fabricmc.fabric.impl.tag.extension.TagDelegate;
import net.fabricmc.fabric.mixin.tag.extension.AccessorFluidTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.Tag;
import net.minecraft.tags.TagCollection;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.material.Fluid;

/**
 * Helper methods for registering Tags.
 */
public final class TagRegistry {
	private TagRegistry() { }

	public static <T> Tag.Named<T> create(ResourceLocation id, Supplier<TagCollection<T>> containerSupplier) {
		return new TagDelegate<>(id, containerSupplier);
	}

	public static Tag<Block> block(ResourceLocation id) {
		return create(id, BlockTags::getAllTags);
	}

	public static Tag<EntityType<?>> entityType(ResourceLocation id) {
		return create(id, EntityTypeTags::getAllTags);
	}

	public static Tag<Fluid> fluid(ResourceLocation id) {
		return create(id, () -> AccessorFluidTags.getRequiredTags().getAllTags());
	}

	public static Tag<Item> item(ResourceLocation id) {
		return create(id, ItemTags::getAllTags);
	}
}
