/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.biome;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.api.biomes.v1.OverworldBiomes;
import net.fabricmc.fabric.impl.biome.InternalBiomeData;
import net.fabricmc.fabric.impl.biome.WeightedBiomePicker;
import net.minecraft.core.Registry;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.newbiome.area.Area;
import net.minecraft.world.level.newbiome.context.Context;
import net.minecraft.world.level.newbiome.layer.Layers;
import net.minecraft.world.level.newbiome.layer.RegionHillsLayer;

/**
 * Injects hills biomes specified from {@link OverworldBiomes#addHillsBiome(Biome, Biome, double)}into the default hills layer.
 */
@Mixin(RegionHillsLayer.class)
public class MixinAddHillsLayer {
	@Inject(at = @At("HEAD"), method = "sample", cancellable = true)
	private void sample(Context rand, Area biomeSampler, Area noiseSampler, int chunkX, int chunkZ, CallbackInfoReturnable<Integer> info) {
		if (InternalBiomeData.getOverworldHills().isEmpty()) {
			// No use doing anything if there are no hills registered. Fall through to vanilla logic.
			return;
		}

		final int biomeId = biomeSampler.get(chunkX, chunkZ);
		int noiseSample = noiseSampler.get(chunkX, chunkZ);
		int processedNoiseSample = (noiseSample - 2) % 29;
		final Biome biome = Registry.BIOME.byId(biomeId);

		WeightedBiomePicker hillPicker = InternalBiomeData.getOverworldHills().get(biome);

		if (hillPicker == null) {
			// No hills for this biome, fall through to vanilla logic.

			return;
		}

		if (rand.nextRandom(3) == 0 || processedNoiseSample == 0) {
			int biomeReturn = Registry.BIOME.getId(hillPicker.pickRandom(rand));
			Biome parent;

			if (processedNoiseSample == 0 && biomeReturn != biomeId) {
				parent = Biome.getMutatedVariant(Registry.BIOME.byId(biomeReturn));
				biomeReturn = parent == null ? biomeId : Registry.BIOME.getId(parent);
			}

			if (biomeReturn != biomeId) {
				int similarity = 0;

				if (Layers.isSame(biomeSampler.get(chunkX, chunkZ - 1), biomeId)) {
					++similarity;
				}

				if (Layers.isSame(biomeSampler.get(chunkX + 1, chunkZ), biomeId)) {
					++similarity;
				}

				if (Layers.isSame(biomeSampler.get(chunkX - 1, chunkZ), biomeId)) {
					++similarity;
				}

				if (Layers.isSame(biomeSampler.get(chunkX, chunkZ + 1), biomeId)) {
					++similarity;
				}

				if (similarity >= 3) {
					info.setReturnValue(biomeReturn);
					return;
				}
			}
		}

		// Cancel vanilla logic.
		info.setReturnValue(biomeId);
	}
}
