/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.block;

import java.util.function.Function;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.Tag;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.level.material.MaterialColor;

/**
 * @deprecated Please migrate to v1. Please use {@link net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings} instead
 */
@Deprecated
public class FabricBlockSettings {
	protected final net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings delegate;

	protected FabricBlockSettings(Material material, MaterialColor color) {
		this(Block.Properties.of(material, color));
	}

	protected FabricBlockSettings(Block base) {
		this(Block.Properties.copy(base));
	}

	protected FabricBlockSettings(final Block.Properties delegate) {
		this.delegate = net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings.copyOf(delegate);
	}

	public static FabricBlockSettings of(Material material) {
		return of(material, material.getColor());
	}

	public static FabricBlockSettings of(Material material, MaterialColor color) {
		return new FabricBlockSettings(material, color);
	}

	public static FabricBlockSettings of(Material material, DyeColor color) {
		return new FabricBlockSettings(material, color.getMaterialColor());
	}

	public static FabricBlockSettings copy(Block base) {
		return new FabricBlockSettings(base);
	}

	public static FabricBlockSettings copyOf(Block.Properties settings) {
		return new FabricBlockSettings(settings);
	}

	/* FABRIC HELPERS */

	public FabricBlockSettings breakByHand(boolean breakByHand) {
		this.delegate.breakByHand(breakByHand);
		return this;
	}

	public FabricBlockSettings breakByTool(Tag<Item> tag, int miningLevel) {
		this.delegate.breakByTool(tag, miningLevel);
		return this;
	}

	public FabricBlockSettings breakByTool(Tag<Item> tag) {
		this.delegate.breakByTool(tag);
		return this;
	}

	/* DELEGATE WRAPPERS */

	public FabricBlockSettings materialColor(MaterialColor color) {
		this.delegate.materialColor(color);
		return this;
	}

	public FabricBlockSettings materialColor(DyeColor color) {
		this.delegate.materialColor(color.getMaterialColor());
		return this;
	}

	public FabricBlockSettings collidable(boolean collidable) {
		this.delegate.collidable(collidable);
		return this;
	}

	public FabricBlockSettings noCollision() {
		this.delegate.noCollission();
		return this;
	}

	public FabricBlockSettings sounds(SoundType group) {
		this.delegate.sound(group);
		return this;
	}

	public FabricBlockSettings ticksRandomly() {
		this.delegate.randomTicks();
		return this;
	}

	public FabricBlockSettings lightLevel(int lightLevel) {
		this.delegate.lightLevel(lightLevel);
		return this;
	}

	public FabricBlockSettings hardness(float hardness) {
		this.delegate.hardness(hardness);
		return this;
	}

	public FabricBlockSettings resistance(float resistance) {
		this.delegate.resistance(resistance);
		return this;
	}

	public FabricBlockSettings strength(float hardness, float resistance) {
		this.delegate.strength(hardness, resistance);
		return this;
	}

	public FabricBlockSettings breakInstantly() {
		this.delegate.instabreak();
		return this;
	}

	public FabricBlockSettings dropsNothing() {
		this.delegate.noDrops();
		return this;
	}

	public FabricBlockSettings dropsLike(Block block) {
		this.delegate.dropsLike(block);
		return this;
	}

	public FabricBlockSettings drops(ResourceLocation dropTableId) {
		this.delegate.drops(dropTableId);
		return this;
	}

	@Deprecated
	public FabricBlockSettings friction(float friction) {
		this.delegate.friction(friction);
		return this;
	}

	public FabricBlockSettings slipperiness(float value) {
		this.delegate.friction(value);
		return this;
	}

	public FabricBlockSettings dynamicBounds() {
		this.delegate.dynamicBounds();
		return this;
	}

	/* BUILDING LOGIC */

	public Block.Properties build() {
		return this.delegate;
	}

	public <T> T build(Function<Block.Properties, T> function) {
		return function.apply(this.delegate);
	}
}
