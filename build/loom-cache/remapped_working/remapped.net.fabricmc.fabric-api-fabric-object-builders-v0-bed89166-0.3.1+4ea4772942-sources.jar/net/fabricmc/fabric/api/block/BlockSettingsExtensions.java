/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.block;

import net.fabricmc.fabric.impl.object.builder.FabricBlockInternals;
import net.fabricmc.fabric.mixin.object.builder.BlockSettingsAccessor;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.Tag;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block.Properties;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.MaterialColor;

/**
 * @deprecated Please migrate to v1. Please use methods in {@link net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings} instead.
 */
@Deprecated
public final class BlockSettingsExtensions {
	private BlockSettingsExtensions() {
	}

	public static void breakByHand(Properties settings, boolean breakByHand) {
		FabricBlockInternals.computeExtraData(settings).breakByHand(breakByHand);
	}

	public static void breakByTool(Properties settings, Tag<Item> tag, int miningLevel) {
		FabricBlockInternals.computeExtraData(settings).addMiningLevel(tag, miningLevel);
	}

	public static void hardness(Properties settings, float hardness) {
		((BlockSettingsAccessor) settings).setHardness(hardness);
	}

	public static void resistance(Properties settings, float resistance) {
		((BlockSettingsAccessor) settings).setResistance(Math.max(0.0F, resistance));
	}

	public static void collidable(Properties settings, boolean collidable) {
		((BlockSettingsAccessor) settings).setCollidable(collidable);
	}

	public static void materialColor(Properties settings, MaterialColor materialColor) {
		((BlockSettingsAccessor) settings).setMaterialColor(materialColor);
	}

	public static void drops(Properties settings, ResourceLocation dropTableId) {
		((BlockSettingsAccessor) settings).setDropTableId(dropTableId);
	}

	public static void sounds(Properties settings, SoundType soundGroup) {
		((BlockSettingsAccessor) settings).invokeSounds(soundGroup);
	}

	public static void lightLevel(Properties settings, int lightLevel) {
		((BlockSettingsAccessor) settings).invokeLightLevel(lightLevel);
	}

	public static void breakInstantly(Properties settings) {
		((BlockSettingsAccessor) settings).invokeBreakInstantly();
	}

	public static void strength(Properties settings, float strength) {
		((BlockSettingsAccessor) settings).invokeStrength(strength);
	}

	public static void ticksRandomly(Properties settings) {
		((BlockSettingsAccessor) settings).invokeTicksRandomly();
	}

	public static void dynamicBounds(Properties settings) {
		// Thanks Mixin
		((BlockSettingsAccessor) settings).setDynamicBounds(true);
	}

	public static void dropsNothing(Properties settings) {
		((BlockSettingsAccessor) settings).invokeDropsNothing();
	}
}
