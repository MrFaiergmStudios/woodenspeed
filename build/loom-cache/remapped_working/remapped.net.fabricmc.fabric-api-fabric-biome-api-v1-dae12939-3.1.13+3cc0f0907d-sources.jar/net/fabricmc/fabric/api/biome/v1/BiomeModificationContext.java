/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.biome.v1;

import java.util.Optional;
import java.util.function.BiPredicate;

import org.jetbrains.annotations.NotNull;
import net.fabricmc.fabric.impl.biome.modification.BuiltInRegistryKeys;
import net.minecraft.class_5458;
import net.minecraft.class_5471;
import net.minecraft.class_5483;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.Music;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.AmbientAdditionsSettings;
import net.minecraft.world.level.biome.AmbientMoodSettings;
import net.minecraft.world.level.biome.AmbientParticleSettings;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.carver.ConfiguredWorldCarver;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.ConfiguredStructureFeature;
import net.minecraft.world.level.levelgen.feature.StructureFeature;
import net.minecraft.world.level.levelgen.surfacebuilders.ConfiguredSurfaceBuilder;

/**
 * Allows {@link Biome} properties to be modified.
 */
public interface BiomeModificationContext {
	/**
	 * @see Biome#getDepth()
	 * @see Biome.BiomeBuilder#depth(float)
	 */
	void setDepth(float depth);

	/**
	 * @see Biome#getScale()
	 * @see Biome.BiomeBuilder#scale(float)
	 */
	void setScale(float scale);

	/**
	 * @see Biome#getBiomeCategory()
	 * @see Biome.BiomeBuilder#biomeCategory(Biome.BiomeCategory)
	 */
	void setCategory(Biome.BiomeCategory category);

	/**
	 * Returns the modification context for the biomes weather properties.
	 */
	WeatherContext getWeather();

	/**
	 * Returns the modification context for the biomes effects.
	 */
	EffectsContext getEffects();

	/**
	 * Returns the modification context for the biomes generation settings.
	 */
	GenerationSettingsContext getGenerationSettings();

	/**
	 * Returns the modification context for the biomes spawn settings.
	 */
	SpawnSettingsContext getSpawnSettings();

	interface WeatherContext {
		/**
		 * @see Biome#getPrecipitation()
		 * @see Biome.BiomeBuilder#precipitation(Biome.Precipitation)
		 */
		void setPrecipitation(Biome.Precipitation precipitation);

		/**
		 * @see Biome#getTemperature()
		 * @see Biome.BiomeBuilder#temperature(float)
		 */
		void setTemperature(float temperature);

		/**
		 * @see class_1959.class_1960#method_30777(class_1959.class_5484)
		 */
		void setTemperatureModifier(Biome.class_5484 temperatureModifier);

		/**
		 * @see Biome#getDownfall()
		 * @see Biome.BiomeBuilder#downfall(float)
		 */
		void setDownfall(float downfall);
	}

	interface EffectsContext {
		/**
		 * @see BiomeSpecialEffects#getFogColor()
		 * @see BiomeSpecialEffects.Builder#fogColor(int)
		 */
		void setFogColor(int color);

		/**
		 * @see BiomeSpecialEffects#getWaterColor()
		 * @see BiomeSpecialEffects.Builder#waterColor(int)
		 */
		void setWaterColor(int color);

		/**
		 * @see BiomeSpecialEffects#getWaterFogColor()
		 * @see BiomeSpecialEffects.Builder#waterFogColor(int)
		 */
		void setWaterFogColor(int color);

		/**
		 * @see BiomeSpecialEffects#method_30810()
		 * @see BiomeSpecialEffects.Builder#method_30820(int)
		 */
		void setSkyColor(int color);

		/**
		 * @see BiomeSpecialEffects#method_30811()
		 * @see BiomeSpecialEffects.Builder#method_30821(int)
		 */
		void setFoliageColor(Optional<Integer> color);

		/**
		 * @see BiomeSpecialEffects#method_30811()
		 * @see BiomeSpecialEffects.Builder#method_30821(int)
		 */
		default void setFoliageColor(int color) {
			setFoliageColor(Optional.of(color));
		}

		/**
		 * @see BiomeSpecialEffects#method_30811()
		 * @see BiomeSpecialEffects.Builder#method_30821(int)
		 */
		default void clearFoliageColor() {
			setFoliageColor(Optional.empty());
		}

		/**
		 * @see BiomeSpecialEffects#method_30812()
		 * @see BiomeSpecialEffects.Builder#method_30822(int)
		 */
		void setGrassColor(Optional<Integer> color);

		/**
		 * @see BiomeSpecialEffects#method_30812()
		 * @see BiomeSpecialEffects.Builder#method_30822(int)
		 */
		default void setGrassColor(int color) {
			setGrassColor(Optional.of(color));
		}

		/**
		 * @see BiomeSpecialEffects#method_30812()
		 * @see BiomeSpecialEffects.Builder#method_30822(int)
		 */
		default void clearGrassColor() {
			setGrassColor(Optional.empty());
		}

		/**
		 * @see class_4763#method_30814()
		 * @see class_4763.class_4764#method_30818(class_4763.class_5486)
		 */
		void setGrassColorModifier(@NotNull BiomeSpecialEffects.class_5486 colorModifier);

		/**
		 * @see BiomeSpecialEffects#getAmbientParticleSettings()
		 * @see BiomeSpecialEffects.Builder#ambientParticle(AmbientParticleSettings)
		 */
		void setParticleConfig(Optional<AmbientParticleSettings> particleConfig);

		/**
		 * @see BiomeSpecialEffects#getAmbientParticleSettings()
		 * @see BiomeSpecialEffects.Builder#ambientParticle(AmbientParticleSettings)
		 */
		default void setParticleConfig(@NotNull AmbientParticleSettings particleConfig) {
			setParticleConfig(Optional.of(particleConfig));
		}

		/**
		 * @see BiomeSpecialEffects#getAmbientParticleSettings()
		 * @see BiomeSpecialEffects.Builder#ambientParticle(AmbientParticleSettings)
		 */
		default void clearParticleConfig() {
			setParticleConfig(Optional.empty());
		}

		/**
		 * @see BiomeSpecialEffects#getAmbientLoopSoundEvent()
		 * @see BiomeSpecialEffects.Builder#ambientLoopSound(SoundEvent)
		 */
		void setAmbientSound(Optional<SoundEvent> sound);

		/**
		 * @see BiomeSpecialEffects#getAmbientLoopSoundEvent()
		 * @see BiomeSpecialEffects.Builder#ambientLoopSound(SoundEvent)
		 */
		default void setAmbientSound(@NotNull SoundEvent sound) {
			setAmbientSound(Optional.of(sound));
		}

		/**
		 * @see BiomeSpecialEffects#getAmbientLoopSoundEvent()
		 * @see BiomeSpecialEffects.Builder#ambientLoopSound(SoundEvent)
		 */
		default void clearAmbientSound() {
			setAmbientSound(Optional.empty());
		}

		/**
		 * @see BiomeSpecialEffects#getAmbientMoodSettings()
		 * @see BiomeSpecialEffects.Builder#ambientMoodSound(AmbientMoodSettings)
		 */
		void setMoodSound(Optional<AmbientMoodSettings> sound);

		/**
		 * @see BiomeSpecialEffects#getAmbientMoodSettings()
		 * @see BiomeSpecialEffects.Builder#ambientMoodSound(AmbientMoodSettings)
		 */
		default void setMoodSound(@NotNull AmbientMoodSettings sound) {
			setMoodSound(Optional.of(sound));
		}

		/**
		 * @see BiomeSpecialEffects#getAmbientMoodSettings()
		 * @see BiomeSpecialEffects.Builder#ambientMoodSound(AmbientMoodSettings)
		 */
		default void clearMoodSound() {
			setMoodSound(Optional.empty());
		}

		/**
		 * @see BiomeSpecialEffects#getAmbientAdditionsSettings()
		 * @see BiomeSpecialEffects.Builder#ambientAdditionsSound(AmbientAdditionsSettings)
		 */
		void setAdditionsSound(Optional<AmbientAdditionsSettings> sound);

		/**
		 * @see BiomeSpecialEffects#getAmbientAdditionsSettings()
		 * @see BiomeSpecialEffects.Builder#ambientAdditionsSound(AmbientAdditionsSettings)
		 */
		default void setAdditionsSound(@NotNull AmbientAdditionsSettings sound) {
			setAdditionsSound(Optional.of(sound));
		}

		/**
		 * @see BiomeSpecialEffects#getAmbientAdditionsSettings()
		 * @see BiomeSpecialEffects.Builder#ambientAdditionsSound(AmbientAdditionsSettings)
		 */
		default void clearAdditionsSound() {
			setAdditionsSound(Optional.empty());
		}

		/**
		 * @see BiomeSpecialEffects#getBackgroundMusic()
		 * @see BiomeSpecialEffects.Builder#backgroundMusic(Music)
		 */
		void setMusic(Optional<Music> sound);

		/**
		 * @see BiomeSpecialEffects#getBackgroundMusic()
		 * @see BiomeSpecialEffects.Builder#backgroundMusic(Music)
		 */
		default void setMusic(@NotNull Music sound) {
			setMusic(Optional.of(sound));
		}

		/**
		 * @see BiomeSpecialEffects#getBackgroundMusic()
		 * @see BiomeSpecialEffects.Builder#backgroundMusic(Music)
		 */
		default void clearMusic() {
			setMusic(Optional.empty());
		}
	}

	interface GenerationSettingsContext {
		/**
		 * Sets the biomes surface builder to a surface builder registered in {@link class_5458#field_25927}.
		 *
		 * <p>This method is intended for use with the surface builders found in {@link class_5471}.
		 *
		 * <p><b>NOTE:</b> In case the configured surface builder is overridden in a datapack, the datapacks version
		 * will be used.
		 */
		default void setBuiltInSurfaceBuilder(ConfiguredSurfaceBuilder<?> configuredSurfaceBuilder) {
			setSurfaceBuilder(BuiltInRegistryKeys.get(configuredSurfaceBuilder));
		}

		/**
		 * Sets the biomes surface builder to the surface builder identified by the given key.
		 */
		void setSurfaceBuilder(ResourceKey<ConfiguredSurfaceBuilder<?>> surfaceBuilderKey);

		/**
		 * Removes a feature from one of this biomes generation steps, and returns if any features were removed.
		 */
		boolean removeFeature(GenerationStep.Decoration step, ResourceKey<ConfiguredFeature<?, ?>> configuredFeatureKey);

		/**
		 * Removes a feature from all of this biomes generation steps, and returns if any features were removed.
		 */
		default boolean removeFeature(ResourceKey<ConfiguredFeature<?, ?>> configuredFeatureKey) {
			boolean anyFound = false;

			for (GenerationStep.Decoration step : GenerationStep.Decoration.values()) {
				if (removeFeature(step, configuredFeatureKey)) {
					anyFound = true;
				}
			}

			return anyFound;
		}

		/**
		 * {@link #removeFeature(ResourceKey)} for built-in features (see {@link #addBuiltInFeature(GenerationStep.Decoration, ConfiguredFeature)}).
		 */
		default boolean removeBuiltInFeature(ConfiguredFeature<?, ?> configuredFeature) {
			return removeFeature(BuiltInRegistryKeys.get(configuredFeature));
		}

		/**
		 * {@link #removeFeature(GenerationStep.Decoration, ResourceKey)} for built-in features (see {@link #addBuiltInFeature(GenerationStep.Decoration, ConfiguredFeature)}).
		 */
		default boolean removeBuiltInFeature(GenerationStep.Decoration step, ConfiguredFeature<?, ?> configuredFeature) {
			return removeFeature(step, BuiltInRegistryKeys.get(configuredFeature));
		}

		/**
		 * Adds a feature to one of this biomes generation steps, identified by the configured feature's registry key.
		 */
		void addFeature(GenerationStep.Decoration step, ResourceKey<ConfiguredFeature<?, ?>> configuredFeatureKey);

		/**
		 * Adds a configured feature from {@link class_5458#field_25929} to this biome.
		 *
		 * <p>This method is intended for use with the configured features found in {@link net.minecraft.class_5464}.
		 *
		 * <p><b>NOTE:</b> In case the configured feature is overridden in a datapack, the datapacks version
		 * will be used.
		 */
		default void addBuiltInFeature(GenerationStep.Decoration step, ConfiguredFeature<?, ?> configuredFeature) {
			addFeature(step, BuiltInRegistryKeys.get(configuredFeature));
		}

		/**
		 * Adds a configured carver to one of this biomes generation steps.
		 */
		void addCarver(GenerationStep.Carving step, ResourceKey<ConfiguredWorldCarver<?>> carverKey);

		/**
		 * Adds a configured carver from {@link class_5458#field_25928} to this biome.
		 *
		 * <p>This method is intended for use with the configured carvers found in {@link net.minecraft.class_5463}.
		 *
		 * <p><b>NOTE:</b> In case the configured carver is overridden in a datapack, the datapacks version
		 * will be used.
		 */
		default void addBuiltInCarver(GenerationStep.Carving step, ConfiguredWorldCarver<?> configuredCarver) {
			addCarver(step, BuiltInRegistryKeys.get(configuredCarver));
		}

		/**
		 * Removes all carvers with the given key from one of this biomes generation steps.
		 *
		 * @return True if any carvers were removed.
		 */
		boolean removeCarver(GenerationStep.Carving step, ResourceKey<ConfiguredWorldCarver<?>> configuredCarverKey);

		/**
		 * Removes all carvers with the given key from all of this biomes generation steps.
		 *
		 * @return True if any carvers were removed.
		 */
		default boolean removeCarver(ResourceKey<ConfiguredWorldCarver<?>> configuredCarverKey) {
			boolean anyFound = false;

			for (GenerationStep.Carving step : GenerationStep.Carving.values()) {
				if (removeCarver(step, configuredCarverKey)) {
					anyFound = true;
				}
			}

			return anyFound;
		}

		/**
		 * {@link #removeCarver(ResourceKey)} for built-in carvers (see {@link #addBuiltInCarver(GenerationStep.Carving, ConfiguredWorldCarver)}).
		 */
		default boolean removeBuiltInCarver(ConfiguredWorldCarver<?> configuredCarver) {
			return removeCarver(BuiltInRegistryKeys.get(configuredCarver));
		}

		/**
		 * {@link #removeCarver(GenerationStep.Carving, ResourceKey)} for built-in carvers (see {@link #addBuiltInCarver(GenerationStep.Carving, ConfiguredWorldCarver)}).
		 */
		default boolean removeBuiltInCarver(GenerationStep.Carving step, ConfiguredWorldCarver<?> configuredCarver) {
			return removeCarver(step, BuiltInRegistryKeys.get(configuredCarver));
		}

		/**
		 * Allows a configured structure to start in this biome.
		 *
		 * <p>Structures added this way may start in this biome, with respect to the {@link net.minecraft.world.level.levelgen.feature.configurations.StructureFeatureConfiguration}
		 * set in the {@link net.minecraft.world.level.chunk.ChunkGenerator}, but structure pieces can always generate in chunks adjacent
		 * to a started structure, regardless of biome.
		 *
		 * <p>Configured structures that have the same underlying {@link StructureFeature} as the given structure will be removed before
		 * adding the new structure, since only one of them could actually generate.
		 *
		 * @see net.minecraft.class_5485.class_5495#method_30995(class_5312)
		 */
		void addStructure(ResourceKey<ConfiguredStructureFeature<?, ?>> configuredStructureKey);

		/**
		 * Allows a configured structure from {@link class_5458#field_25930} to start in this biome.
		 *
		 * <p>This method is intended for use with the configured structures found in {@link net.minecraft.class_5470}.
		 *
		 * <p><b>NOTE:</b> In case the configured structure is overridden using a datapack, the definition from the datapack
		 * will be added to the biome.
		 *
		 * <p>Structures added this way may start in this biome, with respect to the {@link net.minecraft.world.level.levelgen.feature.configurations.StructureFeatureConfiguration}
		 * set in the {@link net.minecraft.world.level.chunk.ChunkGenerator}, but structure pieces can always generate in chunks adjacent
		 * to a started structure, regardless of biome.
		 *
		 * <p>Configured structures that have the same underlying {@link StructureFeature} as the given structure will be removed before
		 * adding the new structure, since only one of them could actually generate.
		 */
		default void addBuiltInStructure(ConfiguredStructureFeature<?, ?> configuredStructure) {
			addStructure(BuiltInRegistryKeys.get(configuredStructure));
		}

		/**
		 * Removes a configured structure from the structures that are allowed to start in this biome.
		 *
		 * <p>Please see the note on {@link #addStructure(ResourceKey)} about structures pieces still generating
		 * if adjacent biomes allow the structure to start.
		 *
		 * @return True if any structures were removed.
		 */
		boolean removeStructure(ResourceKey<ConfiguredStructureFeature<?, ?>> configuredStructureKey);

		/**
		 * Removes a structure from the structures that are allowed to start in this biome.
		 *
		 * <p>This will remove all configured variations of the given structure from this biome.
		 *
		 * <p>This can be used with modded structures or Vanilla structures from {@link net.minecraft.world.level.levelgen.feature.StructureFeature}.
		 *
		 * @return True if any structures were removed.
		 */
		boolean removeStructure(StructureFeature<?> structure);

		/**
		 * {@link #removeStructure(ResourceKey)} for built-in structures (see {@link #addBuiltInStructure(ConfiguredStructureFeature)}).
		 */
		default boolean removeBuiltInStructure(ConfiguredStructureFeature<?, ?> configuredStructure) {
			return removeStructure(BuiltInRegistryKeys.get(configuredStructure));
		}
	}

	interface SpawnSettingsContext {
		/**
		 * Associated JSON property: <code>player_spawn_friendly</code>.
		 *
		 * @see class_5483#method_31082()
		 * @see class_5483.class_5496#method_31083()
		 */
		void setPlayerSpawnFriendly(boolean playerSpawnFriendly);

		/**
		 * Associated JSON property: <code>creature_spawn_probability</code>.
		 *
		 * @see class_5483#method_31002()
		 * @see class_5483.class_5496#method_31008(float)
		 */
		void setCreatureSpawnProbability(float probability);

		/**
		 * Associated JSON property: <code>spawners</code>.
		 *
		 * @see class_5483#method_31004(class_1311)
		 * @see class_5483.class_5496#method_31011(class_1311, class_5483.class_1964)
		 */
		void addSpawn(MobCategory spawnGroup, class_5483.class_1964 spawnEntry);

		/**
		 * Removes any spawns matching the given predicate from this biome, and returns true if any matched.
		 *
		 * <p>Associated JSON property: <code>spawners</code>.
		 */
		boolean removeSpawns(BiPredicate<MobCategory, class_5483.class_1964> predicate);

		/**
		 * Removes all spawns of the given entity type.
		 *
		 * <p>Associated JSON property: <code>spawners</code>.
		 *
		 * @return True if any spawns were removed.
		 */
		default boolean removeSpawnsOfEntityType(EntityType<?> entityType) {
			return removeSpawns((spawnGroup, spawnEntry) -> spawnEntry.field_9389 == entityType);
		}

		/**
		 * Removes all spawns of the given spawn group.
		 *
		 * <p>Associated JSON property: <code>spawners</code>.
		 */
		default void clearSpawns(MobCategory group) {
			removeSpawns((spawnGroup, spawnEntry) -> spawnGroup == group);
		}

		/**
		 * Removes all spawns.
		 *
		 * <p>Associated JSON property: <code>spawners</code>.
		 */
		default void clearSpawns() {
			removeSpawns((spawnGroup, spawnEntry) -> true);
		}

		/**
		 * Associated JSON property: <code>spawn_costs</code>.
		 *
		 * @see class_5483#method_31003(class_1299)
		 * @see class_5483.class_5496#method_31009(class_1299, double, double)
		 */
		void setSpawnCost(EntityType<?> entityType, double mass, double gravityLimit);

		/**
		 * Removes a spawn cost entry for a given entity type.
		 *
		 * <p>Associated JSON property: <code>spawn_costs</code>.
		 */
		void clearSpawnCost(EntityType<?> entityType);
	}
}
