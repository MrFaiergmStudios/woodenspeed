/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.biome;

import java.util.Map;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.fabricmc.fabric.api.biome.v1.OverworldBiomes;
import net.fabricmc.fabric.impl.biome.InternalBiomeData;
import net.fabricmc.fabric.impl.biome.InternalBiomeUtils;
import net.minecraft.class_5504;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.newbiome.area.Area;
import net.minecraft.world.level.newbiome.context.Context;
import net.minecraft.world.level.newbiome.layer.RiverMixerLayer;

/**
 * Sets river biomes specified with {@link OverworldBiomes#setRiverBiome(ResourceKey, ResourceKey)}.
 */
@Mixin(RiverMixerLayer.class)
public class MixinAddRiversLayer {
	@Inject(at = @At("HEAD"), method = "sample", cancellable = true)
	private void sample(Context rand, Area landSampler, Area riverSampler, int x, int z, CallbackInfoReturnable<Integer> info) {
		int landBiomeId = landSampler.get(x, z);
		ResourceKey<Biome> landBiomeKey = class_5504.method_31144(landBiomeId);

		int riverBiomeId = riverSampler.get(x, z);
		Map<ResourceKey<Biome>, ResourceKey<Biome>> overworldRivers = InternalBiomeData.getOverworldRivers();

		if (overworldRivers.containsKey(landBiomeKey) && class_5504.method_31144(riverBiomeId) == Biomes.RIVER) {
			ResourceKey<Biome> riverBiome = overworldRivers.get(landBiomeKey);
			info.setReturnValue(riverBiome == null ? landBiomeId : InternalBiomeUtils.getRawId(riverBiome));
		}
	}
}
