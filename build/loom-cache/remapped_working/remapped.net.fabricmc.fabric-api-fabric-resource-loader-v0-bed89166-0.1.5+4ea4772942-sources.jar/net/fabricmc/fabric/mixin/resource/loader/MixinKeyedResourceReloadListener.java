/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.resource.loader;

import java.util.Collection;
import java.util.Collections;
import java.util.Locale;

import org.spongepowered.asm.mixin.Mixin;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.fabricmc.fabric.api.resource.ResourceReloadListenerKeys;
import net.minecraft.client.gui.font.FontManager;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.language.LanguageManager;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.sounds.SoundBufferLibrary;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.ServerAdvancementManager;
import net.minecraft.server.ServerFunctionManager;
import net.minecraft.tags.TagManager;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.level.storage.loot.LootTables;

public class MixinKeyedResourceReloadListener {
	@Mixin({
			/* public */
			SoundBufferLibrary.class, FontManager.class, ModelManager.class, LanguageManager.class, TextureManager.class,
			/* private */
			LevelRenderer.class, BlockRenderDispatcher.class, ItemRenderer.class
	})
	public abstract static class Client implements IdentifiableResourceReloadListener {
		private Collection<ResourceLocation> fabric_idDeps;
		private ResourceLocation fabric_id;

		@Override
		@SuppressWarnings({"ConstantConditions", "RedundantCast"})
		public Collection<ResourceLocation> getFabricDependencies() {
			if (fabric_idDeps == null) {
				Object self = this;

				if (self instanceof ModelManager || self instanceof LevelRenderer) {
					fabric_idDeps = Collections.singletonList(ResourceReloadListenerKeys.TEXTURES);
				} else if (self instanceof ItemRenderer || self instanceof BlockRenderDispatcher) {
					fabric_idDeps = Collections.singletonList(ResourceReloadListenerKeys.MODELS);
				} else {
					fabric_idDeps = Collections.emptyList();
				}
			}

			return fabric_idDeps;
		}

		@Override
		@SuppressWarnings({"ConstantConditions", "RedundantCast"})
		public ResourceLocation getFabricId() {
			if (fabric_id == null) {
				Object self = this;

				if (self instanceof SoundBufferLibrary) {
					fabric_id = ResourceReloadListenerKeys.SOUNDS;
				} else if (self instanceof FontManager) {
					fabric_id = ResourceReloadListenerKeys.FONTS;
				} else if (self instanceof ModelManager) {
					fabric_id = ResourceReloadListenerKeys.MODELS;
				} else if (self instanceof LanguageManager) {
					fabric_id = ResourceReloadListenerKeys.LANGUAGES;
				} else if (self instanceof TextureManager) {
					fabric_id = ResourceReloadListenerKeys.TEXTURES;
				} else {
					fabric_id = new ResourceLocation("minecraft", "private/" + self.getClass().getSimpleName().toLowerCase(Locale.ROOT));
				}
			}

			return fabric_id;
		}
	}

	@Mixin({
			/* public */
			RecipeManager.class, ServerAdvancementManager.class, ServerFunctionManager.class, LootTables.class, TagManager.class
			/* private */
	})
	public abstract static class Server implements IdentifiableResourceReloadListener {
		private Collection<ResourceLocation> fabric_idDeps;
		private ResourceLocation fabric_id;

		@Override
		@SuppressWarnings({"ConstantConditions", "RedundantCast"})
		public Collection<ResourceLocation> getFabricDependencies() {
			if (fabric_idDeps == null) {
				Object self = this;

				if (self instanceof TagManager) {
					fabric_idDeps = Collections.emptyList();
				} else {
					fabric_idDeps = Collections.singletonList(ResourceReloadListenerKeys.TAGS);
				}
			}

			return fabric_idDeps;
		}

		@Override
		@SuppressWarnings({"ConstantConditions", "RedundantCast"})
		public ResourceLocation getFabricId() {
			if (fabric_id == null) {
				Object self = this;

				if (self instanceof RecipeManager) {
					fabric_id = ResourceReloadListenerKeys.RECIPES;
				} else if (self instanceof ServerAdvancementManager) {
					fabric_id = ResourceReloadListenerKeys.ADVANCEMENTS;
				} else if (self instanceof ServerFunctionManager) {
					fabric_id = ResourceReloadListenerKeys.FUNCTIONS;
				} else if (self instanceof LootTables) {
					fabric_id = ResourceReloadListenerKeys.LOOT_TABLES;
				} else if (self instanceof TagManager) {
					fabric_id = ResourceReloadListenerKeys.TAGS;
				} else {
					fabric_id = new ResourceLocation("minecraft", "private/" + self.getClass().getSimpleName().toLowerCase(Locale.ROOT));
				}
			}

			return fabric_id;
		}
	}
}
